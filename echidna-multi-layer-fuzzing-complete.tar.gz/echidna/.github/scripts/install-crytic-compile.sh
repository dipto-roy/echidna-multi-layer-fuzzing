if [ "$(uname)" != "Darwin" ]; then
    pip3 install slither-analyzer --user
fi
